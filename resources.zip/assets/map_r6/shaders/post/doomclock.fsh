#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D GlyphSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 GlyphSize;
};
layout(std140) uniform ClockConfig {
    vec4 Place;
    vec4 Cell;
    vec4 Ink;
    vec4 Halo;
};
layout(location = 0) out vec4 fragColor;
float at(vec2 texel) {
    if (texel.x < 0.0 || texel.y < 0.0 || texel.x >= Cell.y || texel.y >= Cell.z) { return 0.0; }
    vec2 p = vec2(Cell.w * Cell.y, 0.0) + texel;
    return textureLod(GlyphSampler, (p + 0.5) / GlyphSize, 0.0).a;
}
void main() {
    vec2 frag = vec2(texCoord.x, 1.0 - texCoord.y) * OutSize;
    float k = max(floor(OutSize.y * Place.z / Cell.z + 0.5), 1.0);
    vec2 size = vec2(Cell.y, Cell.z) * k;
    float right = floor(Place.x * OutSize.x + 0.5) - Cell.x * size.x;
    vec2 org = vec2(right - size.x, floor(Place.y * OutSize.y + 0.5));
    vec2 q = frag - org;
    if (q.x < 0.0 || q.x >= size.x || q.y < 0.0 || q.y >= size.y) { discard; }
    vec2 texel = floor(q / k);
    float a = at(texel);
    if (a > 0.75) { fragColor = vec4(Ink.rgb, 1.0); return; }
    if (a > 0.25) { fragColor = vec4(Ink.rgb * 0.22, 1.0); return; }
    if (Ink.w > 0.004) {
        float near = 0.0;
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                float d = float(abs(dx) + abs(dy));
                if (d < 1.0 || d > 3.0) { continue; }
                near = max(near, at(texel + vec2(dx, dy)) > 0.75 ? (4.0 - d) / 3.0 : 0.0);
            }
        }
        if (near > 0.0) {
            vec4 base = vec4(0.0);
            fragColor = vec4(Halo.rgb * (near * Ink.w), 1.0);
            return;
        }
    }
    discard;
}

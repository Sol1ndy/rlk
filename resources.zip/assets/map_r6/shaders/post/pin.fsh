#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D LmbSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform PinConfig {
    vec4 Icon;
    vec4 Bar;
    vec4 Fill;
    vec4 Empty;
    vec4 Border;
    vec4 Style;
};
layout(location = 0) out vec4 fragColor;
void main() {
    vec2 uv = vec2(texCoord.x, 1.0 - texCoord.y);
    vec2 frag = uv * OutSize;
    float unit = Icon.z * OutSize.x;
    vec2 size = max(floor(vec2(unit, unit * Icon.w) + 0.5), vec2(1.0));
    vec2 org = floor(vec2(Icon.x * OutSize.x - size.x * 0.5, Icon.y * OutSize.y) + 0.5);
    vec2 q = frag - org;
    if (q.x >= 0.0 && q.x <= size.x && q.y >= 0.0 && q.y <= size.y) {
        vec2 span = InSize / vec2(Style.w, 1.0);
        vec2 lo = vec2(Style.z, 0.0) * span + 0.5;
        vec2 hi = lo + span - 1.0;
        vec2 at = lo - 0.5 + q / size * span;
        vec2 reach = max(span / size - 1.0, vec2(0.0)) * 0.5;
        vec4 acc = vec4(0.0);
        for (int j = -1; j <= 1; j++) {
            for (int i = -1; i <= 1; i++) {
                vec2 s = clamp(at + vec2(float(i), float(j)) * reach, lo, hi);
                vec4 c = textureLod(LmbSampler, s / InSize, 0.0);
                acc += vec4(c.rgb * c.a, c.a);
            }
        }
        if (acc.a < 4.5) { discard; }
        fragColor = vec4(acc.rgb / acc.a, 1.0);
        return;
    }
    vec2 bsize = max(floor(vec2(unit * Bar.y, unit * Bar.z) + 0.5), vec2(1.0));
    vec2 borg = floor(vec2(Icon.x * OutSize.x - bsize.x * 0.5, org.y + size.y + unit * Bar.x) + 0.5);
    vec2 p = (frag - borg) / bsize;
    if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) { discard; }
    vec2 px = 1.0 / bsize;
    vec2 edge = px * Style.x;
    vec2 pad = px * (Style.x + Style.y);
    if (p.x < edge.x || p.x > 1.0 - edge.x || p.y < edge.y || p.y > 1.0 - edge.y) {
        fragColor = vec4(Border.rgb, 1.0);
        return;
    }
    if (p.x < pad.x || p.x > 1.0 - pad.x || p.y < pad.y || p.y > 1.0 - pad.y) {
        fragColor = vec4(Empty.rgb * 0.45, 1.0);
        return;
    }
    float g = (p.x - pad.x) / (1.0 - 2.0 * pad.x);
    fragColor = vec4(g <= Bar.w ? Fill.rgb : Empty.rgb, 1.0);
}

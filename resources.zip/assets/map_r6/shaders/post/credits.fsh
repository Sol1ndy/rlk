#version 330
#extension GL_ARB_separate_shader_objects : require
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};
uniform sampler2D RollSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform RollConfig {
    vec4 Clock;
    vec4 Span;
    vec4 Look;
};
layout(location = 0) out vec4 fragColor;
void main() {
    float d = mod(GameTime * 24000.0 - Clock.x, 24000.0);
    if (d > 12000.0) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }
    float moved = clamp(d - Clock.z, 0.0, (Span.y - Span.x) / Clock.y) * Clock.y;
    float fade = 1.0 - clamp((d - (Clock.w - Span.z)) / Span.z, 0.0, 1.0);
    vec2 frag = vec2(texCoord.x, 1.0 - texCoord.y) * OutSize;
    float k = max(floor(OutSize.y / Look.x + 0.5), 1.0);
    float off = floor((Span.x + moved) * k + 0.5);
    float ty = floor((frag.y - floor(OutSize.y * 0.5) + off) / k);
    float tx = floor((frag.x - floor(OutSize.x * 0.5 - Span.w * k * 0.5 + 0.5)) / k);
    vec3 rgb = vec3(0.0);
    if (tx >= 0.0 && tx < Span.w && ty >= 0.0 && ty < InSize.y) {
        float f = mod(floor(d / Look.y), 2.0);
        vec4 c = textureLod(RollSampler, (vec2(tx + f * Span.w, ty) + 0.5) / InSize, 0.0);
        rgb = c.rgb * step(0.5, c.a);
    }
    fragColor = vec4(rgb * fade, 1.0);
}

#version 330
#extension GL_ARB_separate_shader_objects : require
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform ShakeConfig {
    vec4 Amp;
};
layout(location = 0) out vec4 fragColor;
void main() {
    float t = GameTime * 24000.0;
    float f = Amp.w;
    float sx = sin(t * f) * 0.65 + sin(t * f * 2.17 + 1.7) * 0.35;
    float sy = sin(t * f * 1.43 + 0.8) * 0.65 + sin(t * f * 2.71 + 2.4) * 0.35;
    float sr = sin(t * f * 0.87 + 2.1) * 0.7 + sin(t * f * 1.91) * 0.3;
    float aspect = OutSize.x / OutSize.y;
    vec2 uv = texCoord - 0.5;
    float ang = radians(Amp.z) * sr;
    float ca = cos(ang);
    float sa = sin(ang);
    uv.x *= aspect;
    uv = vec2(uv.x * ca - uv.y * sa, uv.x * sa + uv.y * ca);
    uv.x /= aspect;
    uv += vec2(sx * Amp.x, sy * Amp.y) + 0.5;
    fragColor = vec4(texture(InSampler, clamp(uv, 0.0, 1.0)).rgb, 1.0);
}

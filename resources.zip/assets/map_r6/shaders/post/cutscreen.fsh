#version 330
#extension GL_ARB_separate_shader_objects : require
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform CutConfig {
    vec4 Lens;
    vec4 Shake;
    vec4 Glitch;
};
layout(location = 0) out vec4 fragColor;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void main() {
    float t = GameTime * 24000.0;
    float f = Shake.w;
    float sx = sin(t * f) * 0.65 + sin(t * f * 2.17 + 1.7) * 0.35;
    float sy = sin(t * f * 1.43 + 0.8) * 0.65 + sin(t * f * 2.71 + 2.4) * 0.35;
    float sr = sin(t * f * 0.87 + 2.1) * 0.7 + sin(t * f * 1.91) * 0.3;
    float aspect = OutSize.x / OutSize.y;
    vec2 uv = (texCoord - 0.5) / Lens.x;
    float ang = radians(Lens.w + Shake.z * sr);
    float ca = cos(ang);
    float sa = sin(ang);
    uv.x *= aspect;
    uv = vec2(uv.x * ca - uv.y * sa, uv.x * sa + uv.y * ca);
    uv.x /= aspect;
    uv += vec2(sx * Shake.x, sy * Shake.y);
    float band = floor(texCoord.y * 36.0);
    float beat = floor(t / 2.0);
    if (hash(vec2(band, beat)) < Glitch.y * 0.35) {
        uv.x += (hash(vec2(band + 7.0, beat)) - 0.5) * 2.0 * Glitch.z;
    }
    uv += 0.5;
    vec2 split = vec2(Glitch.x * (0.6 + 0.4 * sx), 0.0);
    vec3 rgb = vec3(texture(InSampler, clamp(uv + split, 0.0, 1.0)).r,
                    texture(InSampler, clamp(uv, 0.0, 1.0)).g,
                    texture(InSampler, clamp(uv - split, 0.0, 1.0)).b);
    rgb = mix(rgb, vec3(1.0), Lens.z);
    fragColor = vec4(rgb * (1.0 - Lens.y), 1.0);
}

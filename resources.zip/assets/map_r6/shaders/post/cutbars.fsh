#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D BarSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform BarConfig {
    vec4 Bars;
};
layout(location = 0) out vec4 fragColor;
void main() {
    float edge = min(texCoord.y, 1.0 - texCoord.y);
    if (edge >= Bars.x) { discard; }
    fragColor = vec4(texture(BarSampler, vec2(0.5)).rgb, 1.0);
}

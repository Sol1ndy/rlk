#version 330
#extension GL_ARB_separate_shader_objects : require
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};
uniform sampler2D UnderSampler;
uniform sampler2D OverSampler;
uniform sampler2D HeartSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 UnderSize;
    vec2 OverSize;
    vec2 HeartSize;
};
layout(std140) uniform BossConfig {
    vec4 Place;
    vec4 Gauge;
    vec4 Heart;
    vec4 DrainTop;
    vec4 DrainLow;
};
layout(location = 0) out vec4 fragColor;
float bump(float t, float c, float w) {
    float d = (t - c) / w;
    return exp(-d * d);
}
void main() {
    vec2 frag = vec2(texCoord.x, 1.0 - texCoord.y) * OutSize;
    float scale = max(1.0, floor(OutSize.x * Place.x / UnderSize.x));
    vec2 origin = vec2(floor((OutSize.x - UnderSize.x * scale) * 0.5), floor(OutSize.y * Place.y));
    vec2 p = (frag - origin) / scale;
    if (p.x < 0.0 || p.y < 0.0 || p.x >= UnderSize.x || p.y >= UnderSize.y) {
        discard;
    }
    float phase = fract(GameTime * 24000.0 / Place.w);
    float beat = bump(phase, 0.09, 0.055) + 0.55 * bump(phase, 0.36, 0.065) - 0.2 * bump(phase, 0.88, 0.10);
    vec2 t = floor(p);
    vec4 c = texture(UnderSampler, (t + 0.5) / UnderSize);
    if (t.x >= Gauge.x && t.x < Gauge.y && t.y >= Gauge.z && t.y < Gauge.w) {
        float edge = Gauge.x + (Gauge.y - Gauge.x) * Place.z;
        if (t.x >= edge) {
            c.rgb = t.y < Gauge.z + 2.0 ? DrainTop.rgb : DrainLow.rgb;
        } else {
            float d = abs(t.x + 0.5 - UnderSize.x * 0.5) / (UnderSize.x * 0.5);
            float w = (d - phase * 1.5) / 0.10;
            c.rgb *= 1.0 + 0.4 * exp(-w * w) * (1.0 - 0.6 * d);
        }
    }
    vec4 over = texture(OverSampler, (t + 0.5) / OverSize);
    if (over.a > 0.5) {
        c = over;
    }
    float k = Heart.w * beat * smoothstep(Heart.x, Heart.y, p.y);
    vec2 q = vec2(Heart.z + (p.x - Heart.z) / (1.0 - k),
                  p.y > Heart.x ? Heart.x + (p.y - Heart.x) / (1.0 - 0.6 * k) : p.y);
    if (q.x >= 0.0 && q.y >= 0.0 && q.x < HeartSize.x && q.y < HeartSize.y) {
        vec4 h = texture(HeartSampler, (floor(q) + 0.5) / HeartSize);
        if (h.a > 0.5) {
            if (h.r > 2.2 * h.g && h.r > 0.235 && h.b < 0.35) {
                float glow = max(beat, 0.0);
                h.rgb = h.rgb * (1.0 + 0.9 * glow) + vec3(0.0, 0.063, 0.031) * glow;
            }
            c = h;
        }
    }
    if (c.a < 0.5) {
        discard;
    }
    fragColor = vec4(min(c.rgb, vec3(1.0)), 1.0);
}

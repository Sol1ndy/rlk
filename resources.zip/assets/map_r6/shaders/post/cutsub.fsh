#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D TextSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform SubConfig {
    vec4 Place;
};
layout(location = 0) out vec4 fragColor;
void main() {
    vec2 frag = vec2(texCoord.x, 1.0 - texCoord.y) * OutSize;
    float k = max(floor(OutSize.y / Place.z + 0.5), 1.0);
    vec2 size = InSize * k;
    vec2 org = floor(vec2(Place.x * OutSize.x - size.x * 0.5, Place.y * OutSize.y - size.y * 0.5) + 0.5);
    vec2 q = frag - org;
    if (q.x < 0.0 || q.x >= min(size.x, Place.w * k) || q.y < 0.0 || q.y >= size.y) { discard; }
    vec4 c = textureLod(TextSampler, (floor(q / k) + 0.5) / InSize, 0.0);
    if (c.a < 0.5) { discard; }
    fragColor = vec4(c.rgb, 1.0);
}

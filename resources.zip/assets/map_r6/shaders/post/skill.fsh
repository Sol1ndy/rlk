#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D SkillSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform SkillConfig {
    vec4 Rect;
    vec4 Slot;
};
layout(location = 0) out vec4 fragColor;
void main() {
    vec2 uv = vec2(texCoord.x, 1.0 - texCoord.y);
    vec2 frag = uv * OutSize;
    float side = max(floor(Rect.z * OutSize.y + 0.5), 1.0);
    float pitch = side + floor(Rect.w * OutSize.y + 0.5);
    float total = Slot.y * pitch - (pitch - side);
    vec2 org = floor(vec2(Rect.x * OutSize.x - total * 0.5, Rect.y * OutSize.y) + 0.5);
    vec2 q = frag - org - vec2(Slot.z * pitch, 0.0);
    if (q.x < 0.0 || q.x > side || q.y < 0.0 || q.y > side) { discard; }
    vec2 span = InSize / vec2(Slot.y, 1.0);
    vec2 lo = vec2(Slot.z, 0.0) * span + 0.5;
    vec2 hi = lo + span - 1.0;
    vec2 at = lo - 0.5 + q / side * span;
    vec2 reach = max(span / side - 1.0, vec2(0.0)) * 0.5;
    vec3 rgb = vec3(0.0);
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            vec2 s = clamp(at + vec2(float(i), float(j)) * reach, lo, hi);
            rgb += textureLod(SkillSampler, s / InSize, 0.0).rgb;
        }
    }
    rgb /= 9.0;
    vec2 rim = min(q, side - q);
    if (min(rim.x, rim.y) < Slot.x) { rgb = textureLod(SkillSampler, lo / InSize, 0.0).rgb; }
    float cool = Slot.w;
    float top = floor((1.0 - cool) * side + 0.5);
    if (cool > 0.0 && q.y > top) {
        rgb = mix(rgb, vec3(0.16), 0.62);
        if (top > 0.0 && q.y < top + 1.0) { rgb = vec3(0.88); }
    }
    if (cool < 0.0) {
        rgb = mix(rgb, vec3(1.0), -cool * 0.42);
        if (min(rim.x, rim.y) < Slot.x + 1.0) { rgb = mix(rgb, vec3(1.0), -cool); }
    }
    fragColor = vec4(rgb, 1.0);
}

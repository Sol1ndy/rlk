#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
uniform sampler2D DepthSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
void main() {
    vec3 rgb = texture(InSampler, texCoord).rgb;
    float d = texture(DepthSampler, texCoord).r;
    bool far = d < 0.002 || d > 0.9995;
    if (far && max(rgb.r, max(rgb.g, rgb.b)) > 0.004) {
        rgb = vec3(1.0);
    }
    fragColor = vec4(rgb, 1.0);
}

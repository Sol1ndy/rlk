#version 330
#extension GL_ARB_separate_shader_objects : require
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};
uniform sampler2D KeySampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform PromptConfig {
    vec4 Icon;
    vec4 Blink;
};
layout(location = 0) out vec4 fragColor;
void main() {
    vec2 frag = vec2(texCoord.x, 1.0 - texCoord.y) * OutSize;
    float h = Icon.z * OutSize.y;
    vec2 size = max(floor(vec2(h * Icon.w, h) + 0.5), vec2(1.0));
    vec2 org = floor(vec2(Icon.x * OutSize.x - size.x * 0.5, Icon.y * OutSize.y - size.y * 0.5) + 0.5);
    vec2 q = frag - org;
    if (q.x < 0.0 || q.x > size.x || q.y < 0.0 || q.y > size.y) { discard; }
    float shown = mod(floor(GameTime * 24000.0 / Blink.x), Blink.y);
    vec2 span = InSize / vec2(Blink.y, 1.0);
    vec2 lo = vec2(shown, 0.0) * span + 0.5;
    vec2 hi = lo + span - 1.0;
    vec2 at = lo - 0.5 + q / size * span;
    vec2 reach = max(span / size - 1.0, vec2(0.0)) * 0.5;
    vec4 acc = vec4(0.0);
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            vec4 c = textureLod(KeySampler, clamp(at + vec2(float(i), float(j)) * reach, lo, hi) / InSize, 0.0);
            acc += vec4(c.rgb * c.a, c.a);
        }
    }
    if (acc.a < 4.5) { discard; }
    fragColor = vec4(acc.rgb / acc.a, 1.0);
}

#version 330
#extension GL_ARB_separate_shader_objects : require
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform BarConfig {
    vec4 Rect;
    vec4 Fill;
    vec4 Empty;
    vec4 Border;
    vec4 Style;
};
layout(location = 0) out vec4 fragColor;
void main() {
    vec2 uv = vec2(texCoord.x, 1.0 - texCoord.y);
    vec2 p = (uv - Rect.xy) / Rect.zw;
    if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) { discard; }
    vec2 px = 1.0 / (Rect.zw * OutSize);
    vec2 edge = px * Style.y;
    vec2 pad = px * (Style.y + Style.z);
    if (p.x < edge.x || p.x > 1.0 - edge.x || p.y < edge.y || p.y > 1.0 - edge.y) {
        fragColor = vec4(Border.rgb, 1.0);
        return;
    }
    if (p.x < pad.x || p.x > 1.0 - pad.x || p.y < pad.y || p.y > 1.0 - pad.y) {
        fragColor = vec4(Empty.rgb * 0.45, 1.0);
        return;
    }
    float g = (p.x - pad.x) / (1.0 - 2.0 * pad.x);
    fragColor = vec4(g <= Style.x ? Fill.rgb : Empty.rgb, 1.0);
}

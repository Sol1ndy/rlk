#version 330
#extension GL_ARB_separate_shader_objects : require
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform GlowConfig {
    vec4 Body;
    vec4 Rim;
    vec4 Shape;
};
layout(location = 0) out vec4 fragColor;
const float TAU = 6.2831853;
vec2 edge(float d, float s, float reach, float seed) {
    float drift = 0.6 * sin(TAU * (1.3 * s + fract(GameTime * 90.0)) + seed)
                + 0.4 * sin(TAU * (2.9 * s - fract(GameTime * 140.0)) + 2.3 * seed);
    float x = d / (reach * (1.0 + 0.16 * drift));
    float hot = exp(-4.0 * x);
    return vec2(0.45 * hot + 0.55 * exp(-2.2 * x * x), hot);
}
void main() {
    vec3 scene = texture(InSampler, texCoord).rgb;
    float aspect = OutSize.x / OutSize.y;
    vec2 p = vec2(texCoord.x * aspect, texCoord.y);
    float breath = sin(TAU * fract(GameTime * Shape.y));
    float level = Body.a * (1.0 + Shape.z * breath);
    float reach = Shape.x * (0.55 + 0.45 * Body.a) * (1.0 + 0.5 * Shape.z * breath);
    vec2 l = edge(p.x, p.y, reach, 0.0);
    vec2 r = edge(aspect - p.x, p.y, reach, 1.7);
    vec2 b = edge(p.y, p.x, reach, 3.1);
    vec2 t = edge(1.0 - p.y, p.x, reach, 4.6);
    float g = sqrt(l.x * l.x + r.x * r.x + b.x * b.x + t.x * t.x);
    float hot = min(1.0, sqrt(l.y * l.y + r.y * r.y + b.y * b.y + t.y * t.y));
    float k = clamp(g * level * Rim.a, 0.0, 1.0);
    vec3 light = mix(Body.rgb, Rim.rgb, hot);
    vec3 base = mix(scene, vec3(dot(scene, vec3(0.299, 0.587, 0.114))), min(1.0, 1.4 * k));
    base *= mix(vec3(1.0), Body.rgb, min(1.0, 1.2 * k));
    fragColor = vec4(1.0 - (1.0 - base) * (1.0 - light * (0.75 * k)), 1.0);
}

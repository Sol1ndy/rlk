#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform SlowConfig {
    vec4 Amp;
};
layout(location = 0) out vec4 fragColor;
void main() {
    vec2 c = texCoord - 0.5;
    vec2 uv = c * (1.0 - Amp.x) + 0.5;
    float r = min(length(c) * 2.0, 1.0);
    float reach = Amp.y * r * r;
    vec3 sum = vec3(0.0);
    for (int i = 0; i < 6; i++) {
        float k = 1.0 - float(i) * reach * 0.2;
        sum += texture(InSampler, clamp((uv - 0.5) * k + 0.5, 0.0, 1.0)).rgb;
    }
    float shade = 1.0 - Amp.z * smoothstep(0.45, 1.0, r);
    fragColor = vec4(sum / 6.0 * shade, 1.0);
}

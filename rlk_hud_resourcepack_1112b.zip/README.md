# 로그라이크 리소스팩 (`rlk_hud_resourcepack.zip`)

마인크래프트 Java **26.3** 클라이언트용 리소스팩(`pack.mcmeta`: `min_format` 97, `max_format` [97, 1]). 데이터팩 `roguelike`
(네임스페이스 `rlk`, 저장소 https://github.com/Sol1ndy/rlk 의 가지 `claude/exciting-pascal-ek1vuy` — 11-03 기준, 그 뒤의 작업 가지는
데이터팩 README 0-2 1번)와 **짝**이다. 이 README 는 zip 맨 위에 들어 있고 클라이언트는 읽지 않는다. 데이터팩 쪽 인수인계(빌드 ·
릴리스 · 규칙 · 열린 항목)는 데이터팩 `README.md` 의 0장.

- 담긴 것: 글꼴로 그리는 HUD(조준점 · 미니맵 · 보스바 · 보스별 배지 / 계기 글리프), 플레이어 아바타의 전투 모션 모델과 무기,
  잡몹 · 중간보스 · 챕터 보스 · 특수 보스의 디스플레이 엔티티 리그 모델과 텍스처, 효과 카드, 나루카미 경기장 배경, 균열,
  바닐라 HUD 숨기기(하트 · 배고픔 · 갑옷 칸, 흰 보스바를 투명하게).
- 소리 파일은 없다: `assets/rlk/sounds.json` 은 `{}` — 모든 소리는 데이터팩이 바닐라 소리 이벤트로 낸다.
- **같은 빌드 도장끼리 쓴다**: 데이터팩이 로드될 때 채팅에 "빌드 MM-DD …" 가 뜬다. 아래 버전 기록에서 그 줄의 리소스팩을 쓴다
  ("RP 그대로" 인 릴리스는 바로 앞 리소스팩). `pack.mcmeta` 설명 끝의 "빌드 MM-DD" 도 11-03 부터 데이터팩 도장과 같다(그 전
  팩은 "빌드 10-15" 에 멈춰 있었다).

## 1. git 에 없다 — 정본은 마지막으로 보낸 zip
- 리소스팩은 저장소에 없다. **정본 = 사용자에게 마지막으로 보낸 `rlk_hud_resourcepack.zip`**. 이전 세션의 작업 사본(스크래치패드
  `ar/rp_i1/`)은 세션과 함께 사라진다.
- 새 세션은 `--resourcepack` 을 받는 생성기를 돌리기 **전에** 사용자에게 최신 zip 을 받아 빈 폴더에 푼다:
  `mkdir -p <작업>/rp && cd <작업>/rp && unzip -q <받은 zip>` → 생성기에 `--resourcepack <작업>/rp`. 최신인지는 이 README 6절 맨 위
  줄이 데이터팩 README 0-10 맨 위 빌드와 같은지로 본다(README 가 없는 zip 은 11-03 전 것).
  빈 폴더나 오래된 팩에 돌리면 안 된다: 생성기는 자기 몫만 다시 만들고 아이템 아틀라스(`items.json`)에 자기 항목만 합치므로,
  다른 생성기 몫과 아래 "생성기 없음" 자산(다시 만들 수 없음)이 빠진 팩이 된다.
- 묶기(`<out>` 은 내보낼 폴더의 **절대 경로**: `cd` 한 뒤에 쓰므로 상대 경로면 엉뚱한 곳에 생긴다):
  `cd <작업>/rp && rm -f <out>/rlk_hud_resourcepack.zip && zip -qr <out>/rlk_hud_resourcepack.zip pack.mcmeta README.md assets`
  → `unzip -tq` → 크기 보고(11-02: 11,174 KB). `zip` 은 있는 파일에 덧붙이므로 먼저 지운다.
- 11-03 에 사용자에게 「리소스팩을 git 에 넣을지」 물었다. 답이 오기 전까지는 위 방식 그대로다(정본 = 마지막으로 보낸 zip). 넣기로
  하면 저장소의 `resourcepack/` 이 정본이 되고 이 절을 고친다.

## 2. 폴더 지도 (`assets/`)
| 경로 | 내용 |
|---|---|
| `minecraft/atlases/items.json` | 아이템 아틀라스의 소스 목록(11-03: 1 377개, 11-12 라운드 V: 1 505개, 라운드 W: 1 510개; 모두 `minecraft:single`). 30개는 바닐라 블록 텍스처에 별칭 `sprite`(`rlk:cm/<몹>/…`, `rlk:player_motion/<블록>`) |
| `minecraft/textures/gui/sprites/boss_bar/white_{background,progress}.png` | 투명: 흰 바닐라 보스바 막대를 지워 이름 줄(글꼴로 그린 보스바 · 미니맵)만 보이게 |
| `minecraft/textures/gui/sprites/hud/**`(56장) | 투명: 바닐라 하트 · 배고픔 · 갑옷 칸 숨기기(체력은 데이터팩의 액션바 HP 바) |
| `minecraft/textures/entity/zombie/{husk,husk_baby}.png` | 투명(64 × 64, 알파 0; 11-12 라운드 V 레인 VC): 이 팩에서 허스크는 늘 보이지 않는 판정 몸(보스 틀의 몸 · 커스텀 몹의 두뇌 · 프록시)이고, 관전 시점(컷신 카메라)은 투명 생물을 15 % 유령으로 그리므로 그릴 것을 없앤다 — `build_blank_tex.py`. **이 텍스처가 없는 옛 팩으로는 컷신에 갈색 허스크 유령이 보인다** |
| `rlk/font/*.json` + `rlk/textures/font/<글꼴>/*.png` | 글꼴 13개(아래 표) |
| `rlk/items/<…>.json` · `rlk/models/item/<…>.json` · `rlk/textures/<…>.png` | 같은 하위 경로끼리 짝: `items/` 는 아이템 정의(`custom_model_data` 색 · 모습 고르기), `models/item/` 은 블록식 모델, `textures/` 는 그림 |
| `…/cm/` | 잡몹 리그: 1챕터 `sw ar fm im sh cn`, 2챕터 `c2/{ns,slime,sp,dr,fx}` · `kr nj cc ci`, 3챕터 `c3/{fu,fp,em,sb,cw}` · `cs rv pc`; 팔레트 · 소품 `textures/cm/{c2,c2e,c3,c3e}` |
| `…/mboss/<id>/` · `…/mboss/<킷>/` | 보스 리그(`guardian` `butterfly` `fieldgen` `azhdaha` `apep` `apep_om`(아펩 생명체 · 심장 · 돔) `tachy` `arlecchino` `scarlet`(홍련: **몸은 플레이어 아바타와 같은 상자**(머리 8 × 8 × 8, 몸 8 × 12 × 4 를 상체 · 골반으로 나눔, 아바타와 같은 슬림 3픽셀 팔 · 4픽셀 다리, 스킨 1픽셀 = 1/16칸, 크기 1)에 **사용자의 마인크래프트 스킨** `textures/mboss/scarlet/skin.png`(64 × 64, 사용자가 준 파일 그대로)를 바닐라 배치로 입힘; 갓 · 갓끈 · 띠 꼬리 · 칼 · 칼집 · 잔 · 병은 우리 그림(S2c 색, 몸에 맞게 줄인 크기), 손 셋, 얼굴 겹침 `face_fx`, 단계 둘의 갓 매듭 / 띠, 칼 빛 넷, 모든 모델의 유령 쌍둥이 `<model>_g`, 아이템 `item_sword`))와 효과 킷(`bf_kit` `fg_kit` `az_kit` `ap_kit` `tk_kit` `kn_kit` `hr_kit`) |
| `…/raiden/` | 나루카미: 파트 모델은 `items/raiden/*.json` · `models/item/raiden/*.json` 바로 아래(그림 `textures/raiden/rig/`) · `fx/` 색 견본 · `fxg/` 번개 그림(둘 다 `textures/` 에만) · `arena/` 일심정토 배경 패널 · `judgment/` 만겁의 팔 · `clone/` 분신 · `prop/` 소품(만겁 보호막 돔 · 박수 손 · 추모의 꽃 · 씨앗 · 금강저 · 구슬 · 꽂힌 나기나타 등) · `fx_*` 효과 · `skin.png` |
| `…/player_motion/` | 플레이어 아바타(`arle` `skirk` `navia` 의 몸 파트)와 무기(`weapons/`); 홍련 컷신 배우(11-11 레인 H3: `lumine` `clorinde` `ronova` `nefer` 의 10파트 — 다른 셋은 아바타의 것을 그대로 씀 — 와 칼 하나 `weapons/cine_sword` = 아바타 리그의 `sword` 모델); 11-12 라운드 V 레인 VP: 퍼펙트 패링의 **무기 빛** — 리그 무기 다섯의 `weapons/<spear,scythe,sword,cryo_sword,navia_halberd>_glow`(제 요소 + 같은 요소의 발광 껍질, 그림은 `textures/player_motion/weapons/<31장>_hot.png` 절반 해상도의 노란 흰색), 마네킹 캐릭터의 바닐라 검 · 법구용 `wg/{iron_sword,diamond_sword,netherite_sword,orb}`(모델 `wg/{blade,orb}`, 그림 `weapons/wglow_blade.png` · `wglow_orb.png`), 그리고 일곱 캐릭터의 몸 파트 모델 전부에 `tintindex 0`(닷지의 붉은 분홍 몸빛 = `custom_model_data` 색) |
| `…/navia_fx/` · `…/rift/` | 나비아 금빛 카드 · 방 균열 |
| `rlk/items/h/*` | 3인칭에서 손의 바닐라 무기를 감추는 감싸기(`view/av_unwrap` 가 되돌림) |
| `rlk/items/hr_cine/petal_half_{a,b}.json` · `rlk/models/item/hr_cine/petal_half_{a,b}.json` | 홍련 CS1 S11 에서 베인 꽃잎의 반쪽 둘(라운드 W 레인 WC; 그림은 킷의 꽃잎 그림을 반씩 씀, 새 그림 없음) — `build_blank_tex.py` |
| `rlk/items/{claymore,dice,empty,map_button}.json`, `models/item/{claymore,dice}.json`, `textures/item/dice_1..6.png` | 대검 · 주사위 · 빈 모델 · 지도 버튼 |
| `rlk/textures/skin/*.png` | 캐릭터 스킨(`arlecchino clorinde lumine navia nefer ronova skirk`; `lumine` 은 11-11 레인 H3 이 그녀의 프로필 텍스처에서 받아 `tools/player_motion/cine/skin/lumine.png` 에 둔 것을 배우 생성기가 복사; 배우의 스킨 넷 `rlk:skin/{lumine,clorinde,ronova,nefer}` 은 아틀라스 항목; 요이미야 · 활 모델은 11-11 에 지움)과 몹 스킨(`mob_*`); `blank.png`(64 × 64, 알파 0; 11-12 라운드 V 레인 VC: 컷신 동안 숨긴 아바타 · 몹 미끼 마네킹의 스킨 `rlk:skin/blank`) |
| `rlk/sounds.json` | `{}` |

글꼴(글리프 뿌리 텍스트는 늘 비우고 꾸미지 않는다; 킷 글꼴은 끝에 `minecraft:default` 참조가 있어 글자가 기본 글꼴로 나온다):

| 글꼴 | 코드 포인트 | 쓰는 곳 · 만드는 것 |
|---|---|---|
| `rlk:hud` | U+E100–E101 | F5 조준점(제목으로 띄움; 숄더뷰는 11-11 에 없앰) — 생성기 없음 |
| `rlk:minimap` | U+E300–E3F2 | 미니맵(보이지 않는 보스바 이름) — `build_minimap.py` |
| `rlk:bossbar` | U+E400–E438, E440 | 보스바 HP 막대 · 숫자 자리 · 흰 피해 자국 · 아랫줄 · 아랫줄의 칸 구분선 U+E440(`textures/font/bossbar/seg.png` 3 × 7; 11-12 라운드 V 레인 VB: 홍련의 5칸 게이지) — `build_bossbar.py` |
| `rlk:mboss_gd` | U+E500–E5F1 | 파수꾼 P4 화면 — `build_mboss_guardian_rig.mjs`(`guardian_screen.mjs`) |
| `rlk:mboss_bf` · `_fg` · `_az` · `_ap` · `_tk` · `_kn` | U+E600 · E700 · E800 · E900 · EA00 · EB00 대 | 보스별 배지 · 계기 · 화면 번쩍임 — 각 효과 킷 |
| `rlk:mboss_hr` | U+EC10–EC18, EC1F, EC20–EC3F | 홍련의 전체 화면 덮개 여덟(검정 · 반전 · 분홍빛 흰색 · 붉은 기 · 자홍 · 흰색, 144 × 81; 11-11: 금빛 `gold` U+EC17 = 튕겨내기 · 칼 맞댐의 섬광(레인 H2c), 깨진 유리 `web` U+EC18 = 공간 참(레인 H1c, 256 × 144)) · 가장자리 비네트 `vig` U+EC16(가운데 투명; SR 아이템 화무십일홍) · −1 칸 띄우개 U+EC1F · 대사가 떠 있는 동안의 덮개 사라짐 단계 U+EC20–EC3F(덮개마다 20 / 40 / 60 / 80 % 넷, `textures/font/mboss_hr/<덮개>_<1-4>.png`; F2 HR-30) — `build_mboss_hr_fx.py`(글리프 41개) |
| `rlk:bal` | U+ED00–ED22 | 균형치 마름모(노랑 · 빈 칸 · 흰 번쩍임 · 그로기 주황, 몹 머리 밑 줄과 보스바 줄; 11-11 전투 개편 B) — `build_balance.py` |
| `rlk:cb` | U+EE00–EE0D, EE1E, EE1F | 패링 · 닷지 효과(11-12 라운드 V 레인 VP 가 다시 만듦; **모든 셀 ≤ 256 × 256 px** — 넘으면 그 글리프가 네모 상자가 된다, 11-11b 의 512 × 288 금빛 줄): 퍼펙트 패링의 가로 금빛 줄 네 조각 `streak_0..3` U+EE00–EE03(256 × 64 넷을 이어 한 줄) · 따뜻한 화면 색조 `tint` EE04 · 퍼펙트 닷지의 어두운 비네트 `vig` EE05 · 접점의 별 `star` EE06 · 2 / 1단계 패링의 작은 불꽃 `spark` EE07 · 공격자 위의 번개 `bolt_1..3` EE08–EE0A · 닷지의 분홍 터짐 `burst` EE0B · 패링 불가 경고 섬광 두 쪽 `glint_l` · `glint_r` EE0C · EE0D(160 × 64 둘) · 칸 맞춤 EE1E(−1) · EE1F(−257) — `build_combat_fx.py` |

## 3. 어떤 생성기가 어디를 쓰나 (저장소 `roguelike/tools/`)
모든 생성기는 자기 몫 경로에만 쓰고, 아틀라스는 통째로 바꾸지 않고 id 로 합친다.
- **그 안의 낡은 파일까지 지우는 것**: 효과 킷(`build_mboss_*_fx.py`), 보스 리그(`build_mboss_{butterfly,fieldgen,azhdaha,apep}_rig.mjs` ·
  `build_mboss_apep_org.mjs` · `build_tachy_rig.mjs` · `build_arlecchino_rig.mjs` · `build_scarlet_rig.mjs`: 모델 · 아이템 폴더를 비우고 다시 쓰며,
  `mboss_paint_lib.paintSpriteSet` 이 그림에 없는 PNG 와 그 아틀라스 항목을 뺀다; 파수꾼 `build_mboss_guardian_rig.mjs` 는 그림만 지움),
  `build_rift.py`, `build_navia_fx_cards.py`, 나루카미 생성기 대부분.
- **덮어쓰기만 하는 것**: 플레이어 리그(`build_player_rig.mjs` · `weapon_paint.mjs`), 몹 리그(`build_mobs.mjs` 와 그 하위 셋 ·
  `build_swordsman.mjs` · `build_ch2_swarm_rigs.mjs` · `build_ch2_elite_rigs.mjs` · `build_ch3_swarm_rigs.mjs` ·
  `build_ch3_elite_rigs.mjs`), `build_bossbar.py`, `build_minimap.py`. 이들은 지금 쓰는 id 만 아틀라스에서 걸러 다시 넣으므로, 파트 ·
  그림 이름을 바꾸면 옛 그림 · 모델 · 아이템 정의 · 아틀라스 항목이 남는다 — zip 으로 묶기 전에 함께 지운다(그림만 지우고 항목을
  남기면 rplint 가 '없는 텍스처'로 잡는다).
- 아틀라스 합치기: 킷 · RIGLIB 리그는 자기 접두사의 항목 중 없어진 것을 빼고 새 것만 덧붙인다. 1 · 2 · 3챕터 몹 리그와 플레이어 리그의
  블록 별칭은 자기 항목을 지우고 끝에 다시 붙인다(filter-then-push) — 그래서 `items.json` 의 **순서**가 실행 순서에 따라 바뀔 수 있다
  (항목은 같음).
- 실행 위치: 표의 명령은 저장소의 `roguelike/` 에서 `tools/` 를 붙여 돌린다(예:
  `node tools/build_player_rig.mjs --datapack . --resourcepack <RP>`, `node tools/build_mobs.mjs --datapack . --resourcepack <RP>`).
  `--datapack .` 는 `roguelike/` 를 뜻하므로 `tools/` 안에서 돌리면 `tools/data/rlk/function/…` 에 잘못 쓴다(`--datapack` 을 빼면
  기본값 `tools/..` 라 어디서 돌려도 맞다 — 단 `build_cannon.mjs` 는 기본값이 없어 따로 돌릴 때 `--datapack` 이 꼭 필요(`build_mobs.mjs` 는
  늘 넘겨 줌); Python 생성기는 늘 자기 위치 기준). node 리그 생성기는 모두 `--resourcepack <RP>` 가
  필수다: `build_mboss_butterfly_rig.mjs` · `build_mboss_fieldgen_rig.mjs` · `build_mboss_azhdaha_rig.mjs` · `build_mboss_apep_rig.mjs` ·
  `build_mboss_apep_org.mjs` · `build_ch2_swarm_rigs.mjs` · `build_ch3_swarm_rigs.mjs` 에도 `--resourcepack <RP>` 를 붙인다.

| 생성기 | 리소스팩에 쓰는 곳 | 데이터팩 쪽 |
|---|---|---|
| `node build_player_rig.mjs --datapack . --resourcepack <RP>` (+ `weapon_paint.mjs` 등; 11-11 부터 홍련 컷신 배우 `build_player_cine.mjs`, 11-12 부터 박자 동작 · 대역 리그 · 무기 빛 `build_player_beat.mjs` 도 부름: `weapons/*_glow` · `*_hot.png` · `wg/**` · 몸 파트의 `tintindex`; 라운드 W 레인 WP: `_hot` 31장을 90 % 노란흰색 · 불투명도 235 로 — 크기는 같음; 닷지 클립 `dash` · `dash_l` · `dash_b` · `dash2` 는 데이터팩 함수뿐, 팩 변화 없음) | `models/item/player_motion/**` · `items/player_motion/**`(배우의 `{lumine,clorinde,ronova,nefer}/*` · `weapons/cine_sword` 포함), `textures/player_motion/weapons/*`, `textures/skin/lumine.png`, 아틀라스 `rlk:player_motion/*`(블록 별칭) · 스킨 항목(배우의 `rlk:skin/{lumine,clorinde,ronova,nefer}`) | `char/motion/**`(평타 시간표 `char/motion/combat/config/<캐릭터>/<클립>` 포함), `char/cine/**`(배우) |
| `python3 build_navia_fx_cards.py --resourcepack <RP>` | `navia_fx/` | `fx/nv/**` |
| `node build_mobs.mjs --datapack . --resourcepack <RP>`(= `build_shield` · `build_casters_archer` · `build_cannon.mjs`) + `node build_swordsman.mjs`(같은 인자) | `models/item/cm/{sw,sh,fm,im,ar,cn}` · `items/cm/…`, 아틀라스 별칭 `rlk:cm/<몹>/*` | `cm/<몹>/` 포즈 |
| `node build_ch2_swarm_rigs.mjs --resourcepack <RP>` · `node build_ch2_elite_rigs.mjs --resourcepack <RP>` | `cm/c2/**`, `cm/{kr,nj,cc,ci}`, `textures/skin/mob_c2_*` · `mob_{kr,nj,cc}`, `textures/cm/c2*` | `tools/ch2_elite_poses.json`(→ `build_ch2_mobs.py`) |
| `node build_ch3_swarm_rigs.mjs --resourcepack <RP>` · `node build_ch3_elite_rigs.mjs --resourcepack <RP>` | `cm/c3/**`, `cm/{cs,rv,pc}`, `textures/skin/mob_c3_*`, `textures/cm/c3*` | `tools/ch3_elite_poses.json`(→ `build_ch3_mobs.py`) |
| `node build_mboss_guardian_rig.mjs --resourcepack <RP>` | `mboss/guardian/**`, 글꼴 `mboss_gd` | `mboss/guardian/rig/**` + 매니페스트 |
| `node build_mboss_butterfly_rig.mjs --resourcepack <RP>` · `node build_mboss_fieldgen_rig.mjs --resourcepack <RP>` | `mboss/butterfly/**` · `mboss/fieldgen/**` | 각 `rig/**` + 매니페스트 |
| `python3 build_mboss_bf_fx.py --resourcepack <RP>` · `python3 build_mboss_fg_fx.py --resourcepack <RP>` | `mboss/bf_kit/**` · `mboss/fg_kit/**`, 글꼴 `mboss_bf` · `mboss_fg` | 각 모듈의 `fx/**`(킷 몫) |
| `node build_mboss_azhdaha_rig.mjs --resourcepack <RP>` + `python3 build_mboss_az_fx.py --resourcepack <RP>` | `mboss/azhdaha/**` · `mboss/az_kit/**`, 글꼴 `mboss_az` | `boss/azhdaha/rig/**` · `fx/**` |
| `node build_mboss_apep_rig.mjs --resourcepack <RP>` · `node build_mboss_apep_org.mjs --resourcepack <RP>` + `python3 build_mboss_ap_fx.py --resourcepack <RP>` | `mboss/apep/**` · `mboss/apep_om/**` · `mboss/ap_kit/**`, 글꼴 `mboss_ap` | `boss/apep/{rig,om,fx}/**` |
| `python3 build_rift.py --resourcepack <RP>` | `rift/` | `room/rift/**` · `room/obj/k_rift` |
| `python3 build_mboss_tk_fx.py --resourcepack <RP>` + `node build_tachy_rig.mjs --resourcepack <RP>` | `mboss/tk_kit/**` · `mboss/tachy/**`, 글꼴 `mboss_tk` | `boss/tachy/{fx,rig}/**` |
| `python3 build_mboss_kn_fx.py --resourcepack <RP>` + `node build_arlecchino_rig.mjs --resourcepack <RP>` | `mboss/kn_kit/**`(11-03: 그림 45장 — 이번에 `veil` 추가: 2페이즈 변신을 가리는 진홍 불꽃 고치; 프리셋 `cross_thorns` · `shroud` · `shroud_burst` 추가) · `mboss/arlecchino/**`(1페이즈 몸과 낫은 아바타 모델 `player_motion/arle` · `weapons/scythe` 를 참조만 하고 쓰지 않음), 글꼴 `mboss_kn` | `boss/arlecchino/{fx,rig}/**` |
| `python3 build_mboss_hr_fx.py --resourcepack <RP>`(`build_rift.py` 다음) + `node build_scarlet_rig.mjs --resourcepack <RP>`(영상 클립 `scarlet_cine.mjs` 를 가져옴) | `mboss/hr_kit/**`(그림 54장 0.246 M px: 스프라이트 241 664(11-11b: 패링 신호 `cue_0` 64 × 64, 검토 H-A HA-07) + 게이트 아이콘 64 × 64 `rlk:mboss/hr_kit/gate_icon`; 도착 균열 `rift_*` 은 `build_rift.py` 의 `rlk:item/rift/*` 모델을 참조만 함, 없으면 유령 번쩍임 카드; 달무리 `p1b` · `p2b` 는 같은 그림의 색조만 달라 그림이 늘지 않음), 글꼴 `mboss_hr` · `mboss/scarlet/**`(그린 그림 27장 + 사용자 스킨 `skin.png` = 47 872 px; 모델 63개(유령 쌍둥이 포함) + `item_sword` + 슬롯 아이콘 `item_sword_icon`(F-I HR-03: `items/mboss/scarlet/item_sword.json` 이 `display_context` 로 gui · fixed · ground 에서 아이콘, 그 밖에서 `item_sword`); 킷의 면 모양 `hr_kit/qi_arcf_0..3` · `qi_wedgef`(F2 HR-12: 그림 없이 `qi_arc_*` · `qi_wedge` 그림을 다시 씀); 갓 두 개의 아이템 정의에 `minecraft:constant` 색조 — 테 아랫면 그늘; 유령 쌍둥이는 `rlk:mboss/scarlet/ghost` 한 장만 씀), 아틀라스 항목은 id 로 합침; 11-12 라운드 V 레인 VB: 킷 그림 `sw_path`(칼끝의 길) · `sw_head`(길의 별 머리) · `sw_arc_0..2`(베기 조각 세 장면) + 모델 · 아이템 정의, `cue_0` 에 어두운 테; 리그 `glow_edge`(싸움의 흰 칼날 테) 그림 · 모델 · 아이템 정의, `glow_{lilac,pink,violet,gold}` 모델은 십자로 겹친 꼴; 11-12 라운드 W 레인 WB(칼의 궤적 — 지나온 길): `sw_path`(앞으로 갈 길) 그림 · 모델 · 아이템 정의와 `sw_arc_0..2` 의 모델 · 아이템 정의를 지움, `sw_arc_0..2` 그림은 쐐기(현 테 + 잉크 + 옅은 채움)로 다시 그림, 새 그림 `sw_rib_0..2` · `sw_quad_0..2`, 새 모델 · 아이템 정의 `sw_band`(칼날 위의 띠) · `sw_rib_0..2`(몸이 지나온 리본) · `sw_fan_0..2`(쐐기 + 테 벽) · `sw_quad_0..2`(띠 조각); `sw_head` 는 섬광의 별로 남김(킷 그림 59 → 64장, 스프라이트 259 584 px) | `boss/scarlet/{fx,rig}/**` + 매니페스트 둘 |
| `python3 build_bossbar.py --resourcepack <RP>` | 글꼴 `bossbar`(+ 구분선 `textures/font/bossbar/seg.png`), `gui/sprites/boss_bar/*` | `bossui/*` |
| `python3 build_minimap.py --resourcepack <RP>` | 글꼴 `minimap`, `gui/sprites/boss_bar/*` | `minimap/*` |
| `python3 build_balance.py --resourcepack <RP>` | 글꼴 `bal`, `textures/font/bal/*`(9장) | `bal/**` |
| `python3 build_combat_fx.py --resourcepack <RP>` | 글꼴 `cb`, `textures/font/cb/{streak_0,streak_1,streak_2,streak_3,tint,vig,star,spark,bolt_1,bolt_2,bolt_3,burst,glint_l,glint_r}.png`(14장; 옛 `streak` · `streak_s` · `wash` · `glint` 는 지움; 11-12 라운드 W 레인 WP: `tint` 를 더 따뜻하게 · 덮는 세기 절반) | `player/def/fx/g/**` |
| `python3 build_blank_tex.py --resourcepack <RP>`(11-12 라운드 V) | `minecraft/textures/entity/zombie/{husk,husk_baby}.png` · `rlk/textures/skin/blank.png`(셋 다 64 × 64 완전 투명; 아틀라스 항목 없음); 라운드 W: 꽃잎 반쪽 `items/hr_cine/petal_half_{a,b}.json` · `models/item/hr_cine/petal_half_{a,b}.json`(그림은 `rlk:mboss/hr_kit` 의 꽃잎) | 없음(데이터팩은 `char/cine/blank` · `cm/lure_new` 가 `rlk:skin/blank` 를 가리킴) |
| `python3 build_raiden_all.py --resourcepack <RP>`(재료 · 번개 그림 · 배경 · 위험 효과 · 물체 · 구슬 · 서명 효과 · 환영 · 리그 · 순간이동 · 만겁 팔 · 분신, 끝에 `check_raiden_pack.py`) | `raiden/**` | `boss/raiden/**`, `room/raiden/**` |
| **생성기 없음**(손으로 만든 것 · 저장소 밖의 옛 빌드) | 글꼴 `hud` + `textures/font/crosshair.png`, `items/h/*`, `claymore` · `dice` · `empty` · `map_button`, `textures/item/dice_*`, 캐릭터 스킨 · 1챕터 몹 스킨(`mob_{sw,sh,fm,im,ar,cn}`), `raiden/skin.png`(`--skin` 으로 넣음), `gui/sprites/hud/**` | — |

- **홍련 리그 `build_scarlet_rig.mjs`**(I2 = S2c + S2d: 몸은 플레이어 아바타 몸 + 사용자 스킨): 모델 · 아이템 · 그림 폴더 `mboss/scarlet` 을 비우고
  다시 쓰며 아틀라스의 `rlk:mboss/scarlet/*` 항목만 걸러 다시 넣는다(스킨 항목 `rlk:mboss/scarlet/skin` 은 맨 끝에 다시 붙임; 다른 항목 순서
  그대로). 두 번 빌드하면 바이트까지 같다.
  - **몸 모델 15개는 아바타 모델과 똑같다**: 머리 · 허벅지 · 정강이 · 위팔 · 아래팔(손 모양 셋 모두)은
    `models/item/player_motion/skirk/{head,right_leg,right_arm,right_forearm,…}.json` 의 두 상자와 여섯 면 UV 그대로(사용자 스킨이 슬림
    스킨이라 팔은 아바타와 같은 3픽셀), 상체 · 골반은 `skirk/body.json` 의 0-9줄 · 9-12줄(텍스처만 `rlk:mboss/scarlet/skin`). 시험
    `test_rig.py` 의 `body` 검사가 대조한다.
  - **스킨은 생성기가 그리지 않는다**: `tools/scarlet_skin.mjs` 에 든 사용자 PNG 바이트를 그대로 쓴다(바이트 수 · sha1 `7f9726be…` 확인,
    다르면 빌드 중단).
  - 모든 요소는 −16..32 안, 회전은 한 축의 −45 / −22.5 / 0 / 22.5 / 45 만(§4). 갓 테 = 1.32칸 정사각형 넷(0 / 22.5 / 45 / −22.5도,
    0.003칸 간격; 테 반지름 0.66 바깥의 모서리는 투명): 같은 면 겹침 없음, 쐐기 마스크로 반투명 겹침 없음. 갓 몸통 윗면은 몸통과
    같은 16각형(사각 고리 16장 + 가운데 사각형; 모서리가 몸통 밖으로 나오지 않음; 가운데 사각형은 고리 안쪽 가장자리 밑으로 0.005칸
    들어가 그 사이에 가는 틈이 보이지 않음). 유령 쌍둥이는 `rlk:mboss/scarlet/ghost` 한 장만 쓴다.
  - 효과 킷의 잔상 `hr_kit/afterimage.png`(64 × 128, 크기 그대로)는 I2 에서 플레이어 크기 몸의 실루엣으로 다시 그렸다(머리 끝 2.0 ·
    갓 꼭대기 2.31, 카드 2.65칸; S2d 요청 s2d-1). F-I(검토 고침 F2 를 합침): 킷에 면 모양 모델 · 아이템 정의 다섯(`qi_arcf_0..3` ·
    `qi_wedgef`, 새 그림 없음)과 글꼴 단계 글리프 24장이 더해졌다.
  - **슬롯 아이콘 `item_sword_icon`**(F-I, 검토 HR-03): 리그 모델 `item_sword` 는 슬롯에서 0.38 GUI px 실선이라, 아이템 정의가
    `minecraft:select` · `minecraft:display_context` 로 gui · fixed · ground 에서는 같은 칼집 칼을 GUI 픽셀로 다시 그린 아이콘(슬롯 대각선
    20 px, 칼집 2.4 · 손잡이 2.0 px 폭, 코등이 5.2 px; 리그 그림만 → 0 px; `gui_light front`)을, 손 · `item_display` none 에서는
    `item_sword` 를 보인다. 아이콘 모델의 아이템 정의 파일도 같이 생기지만 게임은 쓰지 않는다.

## 4. 규칙
- 경로 · id 는 소문자 `[a-z0-9_.-/]` 만. 하나만 어겨도 클라이언트가 아틀라스나 모델 묶음 전체를 버린다(10-22e: 아펩 생명체 그림의
  대문자 이름 → 모든 아이템 텍스처가 깨짐).
- 아틀라스(`items.json`)는 **id 로 걸러 내고 다시 넣는다(filter-then-push by id)**: 생성기는 자기 id 의 항목만 빼고 넣으며,
  파일을 통째로 새로 쓰거나 남의 항목을 지우지 않는다(손으로도 고치지 않는다). 새 생성기도 이렇게 만든다.
- 텍스트 컴포넌트가 글리프 글꼴을 상속하지 않게 한다: 컴포넌트마다 `font` 를 적고, 글리프 뿌리 텍스트는 비우고 꾸미지 않으며,
  킷 글꼴 끝에 `minecraft:default` 참조(10-14 보스바 숫자, 10-21 배너 글자가 네모로 보였던 문제).
- 글꼴 비트맵의 셀(이미지 ÷ 글자 수)은 **256 × 256 px 이하**, `ascent` ≤ `height`: 넘으면 그 글리프만 말없이 네모 상자가 된다(11-11b 퍼펙트 패링의
  금빛 줄). `rplint.py` 가 모든 글꼴에서 잡는다(11-12 라운드 V).
- 소리는 바닐라만(`sounds.json` 은 `{}` 그대로).
- 모델 요소는 -16..32 안, 회전은 한 축만 −45 · −22.5 · 0 · 22.5 · 45 중 하나, UV 는 0..16(어기면 그 모델이 검정 · 자주 상자로
  보임; 리그 생성기와 `check_raiden_pack.py` 가 막는다).
- 예산: 아이템 아틀라스 합계 ≤ **13.2 M px**(11-03: 12.63 M; 클라이언트 한계 약 15.5 M). 보스 하나는 계획에서 정함(아를레키노 ≤ 1.0 M:
  리그 ≤ 0.15 M · 킷 ≤ 0.70 M). 큰 몫(폴더별): `raiden/` 2.82 M · `mboss/butterfly` 1.33 M · 아바타 무기 `player_motion/weapons` 1.11 M ·
  `mboss/azhdaha` 1.09 M · `mboss/guardian` 1.05 M · `mboss/fg_kit` 0.93 M. 보스별(리그 + 킷): 나루카미 2.82 · 나비 2.16(+ `bf_kit` 0.83) ·
  야타용왕 1.69(+ `az_kit` 0.60) · 역장 1.38(`fieldgen` 0.45 + `fg_kit` 0.93) · 아펩 1.27(`apep` 0.87 + `apep_om` 0.14 + `ap_kit` 0.26) ·
  파수꾼 1.05 · 타키 0.48 · 아를레키노 0.47 · 홍련 0.29 M(`scarlet` 0.048 + `hr_kit` 0.246; 홍련 계획 ≤ 0.43 M: 리그 ≤ 0.15 · 킷 ≤ 0.26 ·
  게이트 아이콘 ≤ 0.005 M; 11-05 I1 에서 합계 12.955 M, I2(플레이어 크기 몸 · 사용자 스킨) 뒤 12.919 M).
  11-12 라운드 V 통합: 합계 **13.108 M**(13 107 904 px, 소스 1 505개; 11-11b 12.940 M + 레인 VP 의 무기 빛 0.149 M(`_hot` 31장 + 빛 카드 둘)
  + 레인 VB 0.019 M(킷 `sw_*` 16 640 + 리그 `glow_edge` 2 048)); 한도까지 0.092 M 남음 — 다음에 넘치면 `_hot` 그림(절반 해상도)을 더 줄이거나
  무기끼리 나눠 쓰는 것이 가장 싸다.
  11-12 라운드 W 통합: 합계 **13.109 M**(13 109 184 px, 소스 1 510개; 라운드 V 13.108 M + 레인 WB 1 280 px(`sw_rib_*` 3 × 256 + `sw_quad_*` 3 × 256 −
  `sw_path` 256); 레인 WC 의 꽃잎 반쪽 · 레인 WP 의 `tint` · `_hot` 은 그림 크기가 같음); 한도까지 0.091 M 남음.

## 5. 검사와 다시 만들기
- 린트: `python3 -I roguelike/tools/dev/rplint.py <RP>` → `rplint: 0 problem(s)`(경로 글자, 아틀라스 id · 없는 텍스처, 깨진 JSON, 글꼴 셀 256 px · `ascent` · 없는 비트맵 · 줄 길이가 다른 `chars`).
- 아틀라스 크기: `python3 -I roguelike/tools/dev/atlas_px.py <RP>`.
- 두 번 만들기: 바꾼 생성기를 두 번 돌려 해시가 같은지 — `(cd <RP> && find . -type f -print0 | sort -z | xargs -0 sha1sum) | sha1sum`
  (같은 순서로 돌릴 때만 비교한다: 위 순서 문제).
- 클라이언트 확인: 게임에서 F3+T(리소스 다시 읽기). 모델이 검정 · 자주 상자면 그 모델, 모든 텍스처가 깨지면 아틀라스(대개 이름 글자).

## 6. 버전 기록 (최신이 위, 데이터팩 빌드 도장과 같음; **릴리스마다 한 줄 추가**)
- 11-12b · 2차 테스트 반영(홍련 킷: 검로 잔상 `sw_band` · `sw_rib_0..2` · `sw_fan_*` · `sw_quad_0..2`, `sw_arc_*` 다시 그림, `sw_path` 삭제; 반쪽 꽃잎 `hr_cine/petal_half_{a,b}`; `font/cb/tint.png` · 무기 `_hot` 다시 그림; 아틀라스 13.109 M)
- 11-12 · 플레이 테스트 반영(글꼴 `rlk:cb` 다시 만듦: 모든 칸 256 px 이하 — 줄은 256 × 64 조각 넷 · 색조 · 가장자리 어둠 · 별 · 불꽃 · 번개; 무기 발광 모델 `weapons/*_glow` · `wg/*` 와 `_hot` 텍스처; 마네킹 캐릭터의 대역 리그 몸 파트 색조; 홍련 킷의 검 경로 · 검기 카드 `sw_*` · 칼날 테두리 `glow_edge` · 신호 별 `cue_0`; 보스바 게이지 구분선 `seg.png`; 투명 텍스처 `entity/zombie/husk*.png` · `skin/blank.png`; 아틀라스 13.108 M)
- 11-11b · 홍련 재완성(킷 `hr_kit` 에 패링 신호 그림 `cue_0` 추가(54장); 컷신 배우 모델 `player_motion/{lumine,clorinde,ronova,nefer}` · `weapons/cine_sword` · 스킨 `skin/lumine`; 글꼴 `mboss_hr` 에 덮개 `gold` · `web` 과 그 사라짐 단계 추가(U+EC17–EC18, EC38–EC3F); 아틀라스 12.940 M)
- 11-11 · 전투 개편(글꼴 `rlk:bal` 균형치 마름모 U+ED00–ED22 · `rlk:cb` 패링 · 닷지 효과 U+EE00–EE04 · EE0F 추가; 요이미야 스킨 · 활 당기기 모델 `bow_pull_0..2` · `h/bow` · `h/bow_pull_0..2` 삭제; 아틀라스 그대로 12.919 M)
- 11-06 · 홍련 · 특수 보스(리그 `mboss/scarlet`: 몸은 플레이어 아바타 몸 + 사용자 스킨 `skin.png`, 모델 63개 · 그림 27장 + 슬롯 아이콘 `item_sword_icon`; 킷 `hr_kit` 그림 53장 · 게이트 아이콘; 글꼴 `mboss_hr`; 아틀라스 12.919 M) · `pack.mcmeta` 설명 빌드 11-06(데이터팩 빌드 도장 커밋 `c77e5d1`)
- 11-03 · 아를레키노 수정(죽음의 칼날의 칼날이 십자선을 따라 날아와 터지고 가시가 솟음, 낫이 안 보이던 문제, 돌아오는 낫 방향, 2페이즈 변신의 진홍 불꽃 고치) · 킷 그림 `veil` 추가 · `pack.mcmeta` 설명을 빌드 도장과 맞춤 · 이 README 처음 넣음(데이터팩 빌드 도장 커밋 `96884f2`)
- 11-02 · 아를레키노 · 4챕터(리그 `mboss/arlecchino`, 킷 `kn_kit`, 글꼴 `mboss_kn`; 11,174 KB)
- 10-30d · 타키 얼굴 수정 / 10-30c · 타키 조정 · 문 높이 / 10-30b · 타키 · 균열 / 10-30 · 타키 · 균열(검토 전)(`mboss/tachy`, `tk_kit`, `mboss_tk`)
- 10-29d · 균열(시험용 보스)(`rift/`) / 10-29c · 무기 방향 수정(RP 그대로) / 10-29b · 3챕터 잡몹(`cm/c3` · `cs rv pc`) / 10-29 · 명령어 help(RP 그대로)
- 10-28 · 2챕터 잡몹(`cm/c2` · `kr nj cc ci`)
- 10-24 · 포영 검기 모양 수정(나루카미 검기 그림)
- 10-22j · 라이덴 계수 하향(RP 그대로) / 10-22i · 만겁 보호막 베기 / 10-22h · 만겁 팔 펴서 베기 / 10-22g · 라이덴 · 아펩 수정 / 10-22f · 아펩 패턴 수정
- 10-22e · 리소스팩 텍스처 수정(아펩 그림 이름 소문자, 이때부터 rplint) / 10-22d · 아펩(`mboss/apep` · `apep_om` · `ap_kit` · `mboss_ap`)
- 10-22c · 라이덴 텐마 갑주 · 일심정토 / 10-22b · 라이덴 동작 · 순간이동 · 분신 / 10-22a · 라이덴 보호막 · 만겁 / 10-22 · 라이덴 개편(`raiden/` 새로)
- 10-21d · 보스 팁 정리(RP 그대로) / 10-21c · 야타용왕 버그 수정(킷 글꼴이 기본 글꼴로 이어짐) / 10-21b · 야타용왕 AI 수정(RP 그대로) / 10-21 · 야타용왕(`mboss/azhdaha` · `az_kit` · `mboss_az`)
- 10-20 · 예고 · 계수 조정 / 10-19 · 역장 발생 장치(`mboss/fieldgen` · `fg_kit`) / 10-19 · 나비 조정 / 10-18 · 달빛 환영 나비(`mboss/butterfly` · `bf_kit`) / 10-18 · 이동 · 상자
- 10-17 · 중간보스(파수꾼 `mboss/guardian`, `mboss_gd`) / 10-17 · 나비아(아바타 · `navia_fx`) / 10-16 / 10-15b / 10-15 / 10-14d / 10-14c / 10-14b(보스바 숫자 글꼴) / 10-14(글꼴 미니맵 · 보스바 · 빌드 도장 시작)
